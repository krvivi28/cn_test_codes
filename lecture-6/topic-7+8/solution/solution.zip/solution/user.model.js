export const user = {
  name: "coding ninjas",
  email: "ninja@gmail.com",
  image: "https://entrackr.com/storage/2022/10/Coding-Ninjas.jpg",
};
