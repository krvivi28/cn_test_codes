// Please do not change the prewritten code

const http = require("http");

const server = http.createServer(function requestListner(request, response) {
  //write your code here
});
module.exports = server;
